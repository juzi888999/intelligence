package ${package};

import com.jmcloud.intelligence.common.feign.annotation.EnableIntelligenceFeignClients;
import com.jmcloud.intelligence.common.security.annotation.EnableIntelligenceResourceServer;
import com.jmcloud.intelligence.common.swagger.annotation.EnableIntelligenceSwagger2;
import org.springframework.boot.SpringApplication;
import org.springframework.cloud.client.SpringCloudApplication;

/**
 * @author intelligence archetype
 * <p>
 * 项目启动类
 */
@EnableIntelligenceSwagger2
@SpringCloudApplication
@EnableIntelligenceFeignClients
@EnableIntelligenceResourceServer
public class App {
    public static void main(String[] args) {
        SpringApplication.run(App.class, args);
    }
}
