/*
 * @author intelligence archetype
 * <p>
 * 常量和枚举定义
 */
package ${package}.constant;