/*
  @author intelligence archetype
 * <p>
 * feign client 存放目录，注意 @EnableIntelligenceFeignClients 的扫描范围
 */
package ${package}.api.feign;