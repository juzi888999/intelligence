/*
 * @author intelligence archetype
 * <p>
 * 实体 存放目录
 */
package ${package}.entity;