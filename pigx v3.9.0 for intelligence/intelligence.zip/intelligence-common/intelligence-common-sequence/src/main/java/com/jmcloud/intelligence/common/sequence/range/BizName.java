package com.jmcloud.intelligence.common.sequence.range;

/**
 * @author intelligence
 * @date 2019-05-26
 * <p>
 * 名称生成器
 */
public interface BizName {

	/**
	 * 生成名称
	 * @return 返回文本序号
	 */
	String create();

}
