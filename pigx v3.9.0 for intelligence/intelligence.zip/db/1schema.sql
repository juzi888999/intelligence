-- intelligence 核心表
create database `intelligencex` default character set utf8mb4 collate utf8mb4_general_ci;

-- intelligence 工作流相关库
create database `intelligencex_ac` default character set utf8mb4 collate utf8mb4_general_ci;

-- intelligence 任务相关库
create database `intelligencex_job` default character set utf8mb4 collate utf8mb4_general_ci;

-- intelligence 公众号管理相关库
create database `intelligencex_mp` default character set utf8mb4 collate utf8mb4_general_ci;

-- intelligence nacos配置相关库
create database `intelligencex_config` default character set utf8mb4 collate utf8mb4_general_ci;

-- intelligence pay配置相关库
create database `intelligencex_pay` default character set utf8mb4 collate utf8mb4_general_ci;

-- intelligence codegen相关库
create database `intelligencex_codegen` default character set utf8mb4 collate utf8mb4_general_ci;